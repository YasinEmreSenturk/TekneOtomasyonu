﻿namespace Projem
{
    partial class Odeme
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Odeme));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties17 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties18 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties19 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties20 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties21 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties22 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties23 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties24 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Otarih = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Ofiyattb = new Bunifu.UI.WinForms.BunifuTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.guna2CirclePictureBox2 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.Oadcb = new System.Windows.Forms.ComboBox();
            this.OdemeDGV = new Guna.UI2.WinForms.Guna2DataGridView();
            this.Aratb = new Bunifu.UI.WinForms.BunifuTextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OdemeDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.Turquoise;
            this.label2.Location = new System.Drawing.Point(551, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(164, 37);
            this.label2.TabIndex = 6;
            this.label2.Text = "Ödemeler";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.Turquoise;
            this.label1.Location = new System.Drawing.Point(350, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(162, 37);
            this.label1.TabIndex = 5;
            this.label1.Text = "YEŞ TEKNE";
            // 
            // Otarih
            // 
            this.Otarih.CalendarFont = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Otarih.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Otarih.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.Otarih.Location = new System.Drawing.Point(38, 199);
            this.Otarih.Name = "Otarih";
            this.Otarih.Size = new System.Drawing.Size(250, 28);
            this.Otarih.TabIndex = 7;
            this.Otarih.ValueChanged += new System.EventHandler(this.Otarih_ValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.Turquoise;
            this.label4.Location = new System.Drawing.Point(31, 244);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(157, 37);
            this.label4.TabIndex = 9;
            this.label4.Text = "Tekne Adı";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.Turquoise;
            this.label7.Location = new System.Drawing.Point(31, 341);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(178, 37);
            this.label7.TabIndex = 14;
            this.label7.Text = "Tekne Fiyat";
            // 
            // Ofiyattb
            // 
            this.Ofiyattb.AcceptsReturn = false;
            this.Ofiyattb.AcceptsTab = false;
            this.Ofiyattb.AnimationSpeed = 200;
            this.Ofiyattb.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Ofiyattb.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Ofiyattb.AutoSizeHeight = true;
            this.Ofiyattb.BackColor = System.Drawing.Color.Transparent;
            this.Ofiyattb.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Ofiyattb.BackgroundImage")));
            this.Ofiyattb.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.Ofiyattb.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.Ofiyattb.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.Ofiyattb.BorderColorIdle = System.Drawing.Color.Silver;
            this.Ofiyattb.BorderRadius = 1;
            this.Ofiyattb.BorderThickness = 1;
            this.Ofiyattb.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.Ofiyattb.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Ofiyattb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Ofiyattb.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.Ofiyattb.DefaultText = "";
            this.Ofiyattb.FillColor = System.Drawing.Color.White;
            this.Ofiyattb.HideSelection = true;
            this.Ofiyattb.IconLeft = null;
            this.Ofiyattb.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.Ofiyattb.IconPadding = 10;
            this.Ofiyattb.IconRight = null;
            this.Ofiyattb.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.Ofiyattb.Lines = new string[0];
            this.Ofiyattb.Location = new System.Drawing.Point(38, 381);
            this.Ofiyattb.MaxLength = 32767;
            this.Ofiyattb.MinimumSize = new System.Drawing.Size(1, 1);
            this.Ofiyattb.Modified = false;
            this.Ofiyattb.Multiline = false;
            this.Ofiyattb.Name = "Ofiyattb";
            stateProperties17.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties17.FillColor = System.Drawing.Color.Empty;
            stateProperties17.ForeColor = System.Drawing.Color.Empty;
            stateProperties17.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Ofiyattb.OnActiveState = stateProperties17;
            stateProperties18.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties18.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties18.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.Ofiyattb.OnDisabledState = stateProperties18;
            stateProperties19.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties19.FillColor = System.Drawing.Color.Empty;
            stateProperties19.ForeColor = System.Drawing.Color.Empty;
            stateProperties19.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Ofiyattb.OnHoverState = stateProperties19;
            stateProperties20.BorderColor = System.Drawing.Color.Silver;
            stateProperties20.FillColor = System.Drawing.Color.White;
            stateProperties20.ForeColor = System.Drawing.Color.Empty;
            stateProperties20.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Ofiyattb.OnIdleState = stateProperties20;
            this.Ofiyattb.Padding = new System.Windows.Forms.Padding(3);
            this.Ofiyattb.PasswordChar = '\0';
            this.Ofiyattb.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.Ofiyattb.PlaceholderText = "";
            this.Ofiyattb.ReadOnly = false;
            this.Ofiyattb.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Ofiyattb.SelectedText = "";
            this.Ofiyattb.SelectionLength = 0;
            this.Ofiyattb.SelectionStart = 0;
            this.Ofiyattb.ShortcutsEnabled = true;
            this.Ofiyattb.Size = new System.Drawing.Size(250, 43);
            this.Ofiyattb.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.Ofiyattb.TabIndex = 13;
            this.Ofiyattb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Ofiyattb.TextMarginBottom = 0;
            this.Ofiyattb.TextMarginLeft = 3;
            this.Ofiyattb.TextMarginTop = 1;
            this.Ofiyattb.TextPlaceholder = "";
            this.Ofiyattb.UseSystemPasswordChar = false;
            this.Ofiyattb.WordWrap = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.Turquoise;
            this.label3.Location = new System.Drawing.Point(31, 147);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(182, 37);
            this.label3.TabIndex = 15;
            this.label3.Text = "Ödeme Ayı";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.PaleTurquoise;
            this.button2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.button2.Location = new System.Drawing.Point(38, 446);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(114, 38);
            this.button2.TabIndex = 30;
            this.button2.Text = "Ödeme";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.button1.Location = new System.Drawing.Point(174, 446);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(114, 38);
            this.button1.TabIndex = 31;
            this.button1.Text = "Yenile";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.PaleTurquoise;
            this.button3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button3.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.button3.Location = new System.Drawing.Point(99, 501);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(114, 38);
            this.button3.TabIndex = 32;
            this.button3.Text = "Geri";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // guna2CirclePictureBox1
            // 
            this.guna2CirclePictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2CirclePictureBox1.Image")));
            this.guna2CirclePictureBox1.ImageRotate = 0F;
            this.guna2CirclePictureBox1.Location = new System.Drawing.Point(12, 9);
            this.guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            this.guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox1.Size = new System.Drawing.Size(109, 109);
            this.guna2CirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox1.TabIndex = 35;
            this.guna2CirclePictureBox1.TabStop = false;
            // 
            // guna2CirclePictureBox2
            // 
            this.guna2CirclePictureBox2.Image = global::Projem.Properties.Resources.ship_boat__1_;
            this.guna2CirclePictureBox2.ImageRotate = 0F;
            this.guna2CirclePictureBox2.Location = new System.Drawing.Point(835, 9);
            this.guna2CirclePictureBox2.Name = "guna2CirclePictureBox2";
            this.guna2CirclePictureBox2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox2.Size = new System.Drawing.Size(65, 62);
            this.guna2CirclePictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox2.TabIndex = 37;
            this.guna2CirclePictureBox2.TabStop = false;
            this.guna2CirclePictureBox2.Click += new System.EventHandler(this.guna2CirclePictureBox2_Click);
            // 
            // Oadcb
            // 
            this.Oadcb.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Oadcb.FormattingEnabled = true;
            this.Oadcb.Items.AddRange(new object[] {
            "08:00 - 09:00",
            "09:00 - 10:00",
            "10:00 - 11:00",
            "11:00 - 12:00",
            "12:00 - 13:00",
            "13:00 - 14:00",
            "14:00 - 15:00",
            "15:00 - 16:00",
            "16:00 - 17:00"});
            this.Oadcb.Location = new System.Drawing.Point(38, 297);
            this.Oadcb.Name = "Oadcb";
            this.Oadcb.Size = new System.Drawing.Size(260, 31);
            this.Oadcb.TabIndex = 38;
            // 
            // OdemeDGV
            // 
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.White;
            this.OdemeDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.OdemeDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.OdemeDGV.ColumnHeadersHeight = 30;
            this.OdemeDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.OdemeDGV.DefaultCellStyle = dataGridViewCellStyle9;
            this.OdemeDGV.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.OdemeDGV.Location = new System.Drawing.Point(320, 165);
            this.OdemeDGV.Name = "OdemeDGV";
            this.OdemeDGV.RowHeadersVisible = false;
            this.OdemeDGV.RowHeadersWidth = 51;
            this.OdemeDGV.RowTemplate.Height = 25;
            this.OdemeDGV.Size = new System.Drawing.Size(580, 374);
            this.OdemeDGV.TabIndex = 39;
            this.OdemeDGV.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.OdemeDGV.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.OdemeDGV.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.OdemeDGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.OdemeDGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.OdemeDGV.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.OdemeDGV.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.OdemeDGV.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.OdemeDGV.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.OdemeDGV.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.OdemeDGV.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.OdemeDGV.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.OdemeDGV.ThemeStyle.HeaderStyle.Height = 30;
            this.OdemeDGV.ThemeStyle.ReadOnly = false;
            this.OdemeDGV.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.OdemeDGV.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.OdemeDGV.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.OdemeDGV.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.OdemeDGV.ThemeStyle.RowsStyle.Height = 25;
            this.OdemeDGV.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.OdemeDGV.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.White;
            // 
            // Aratb
            // 
            this.Aratb.AcceptsReturn = false;
            this.Aratb.AcceptsTab = false;
            this.Aratb.AnimationSpeed = 200;
            this.Aratb.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Aratb.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Aratb.AutoSizeHeight = true;
            this.Aratb.BackColor = System.Drawing.Color.Transparent;
            this.Aratb.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Aratb.BackgroundImage")));
            this.Aratb.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.Aratb.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.Aratb.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.Aratb.BorderColorIdle = System.Drawing.Color.Silver;
            this.Aratb.BorderRadius = 1;
            this.Aratb.BorderThickness = 1;
            this.Aratb.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.Aratb.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Aratb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Aratb.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.Aratb.DefaultText = "";
            this.Aratb.FillColor = System.Drawing.Color.White;
            this.Aratb.HideSelection = true;
            this.Aratb.IconLeft = null;
            this.Aratb.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.Aratb.IconPadding = 10;
            this.Aratb.IconRight = null;
            this.Aratb.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.Aratb.Lines = new string[0];
            this.Aratb.Location = new System.Drawing.Point(357, 110);
            this.Aratb.MaxLength = 32767;
            this.Aratb.MinimumSize = new System.Drawing.Size(1, 1);
            this.Aratb.Modified = false;
            this.Aratb.Multiline = false;
            this.Aratb.Name = "Aratb";
            stateProperties21.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties21.FillColor = System.Drawing.Color.Empty;
            stateProperties21.ForeColor = System.Drawing.Color.Empty;
            stateProperties21.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Aratb.OnActiveState = stateProperties21;
            stateProperties22.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties22.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties22.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.Aratb.OnDisabledState = stateProperties22;
            stateProperties23.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties23.FillColor = System.Drawing.Color.Empty;
            stateProperties23.ForeColor = System.Drawing.Color.Empty;
            stateProperties23.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Aratb.OnHoverState = stateProperties23;
            stateProperties24.BorderColor = System.Drawing.Color.Silver;
            stateProperties24.FillColor = System.Drawing.Color.White;
            stateProperties24.ForeColor = System.Drawing.Color.Empty;
            stateProperties24.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Aratb.OnIdleState = stateProperties24;
            this.Aratb.Padding = new System.Windows.Forms.Padding(3);
            this.Aratb.PasswordChar = '\0';
            this.Aratb.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.Aratb.PlaceholderText = "";
            this.Aratb.ReadOnly = false;
            this.Aratb.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Aratb.SelectedText = "";
            this.Aratb.SelectionLength = 0;
            this.Aratb.SelectionStart = 0;
            this.Aratb.ShortcutsEnabled = true;
            this.Aratb.Size = new System.Drawing.Size(260, 38);
            this.Aratb.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.Aratb.TabIndex = 40;
            this.Aratb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Aratb.TextMarginBottom = 0;
            this.Aratb.TextMarginLeft = 3;
            this.Aratb.TextMarginTop = 1;
            this.Aratb.TextPlaceholder = "";
            this.Aratb.UseSystemPasswordChar = false;
            this.Aratb.WordWrap = true;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.PaleTurquoise;
            this.button4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button4.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.button4.Location = new System.Drawing.Point(786, 110);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(114, 38);
            this.button4.TabIndex = 42;
            this.button4.Text = "Yenile";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.PaleTurquoise;
            this.button5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button5.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.button5.Location = new System.Drawing.Point(635, 110);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(114, 38);
            this.button5.TabIndex = 41;
            this.button5.Text = "Ara";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // Odeme
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(912, 563);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.Aratb);
            this.Controls.Add(this.OdemeDGV);
            this.Controls.Add(this.Oadcb);
            this.Controls.Add(this.guna2CirclePictureBox2);
            this.Controls.Add(this.guna2CirclePictureBox1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Ofiyattb);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Otarih);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Odeme";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Odeme";
            this.Load += new System.EventHandler(this.Odeme_Load);
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OdemeDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker Otarih;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private Bunifu.UI.WinForms.BunifuTextBox Ofiyattb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox2;
        private System.Windows.Forms.ComboBox Oadcb;
        private Guna.UI2.WinForms.Guna2DataGridView OdemeDGV;
        private Bunifu.UI.WinForms.BunifuTextBox Aratb;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
    }
}