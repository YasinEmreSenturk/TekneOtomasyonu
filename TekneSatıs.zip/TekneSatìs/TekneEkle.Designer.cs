﻿namespace Projem
{
    partial class TekneEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TekneEkle));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.ZamanlamaCb = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.guna2CirclePictureBox2 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.Tfiyattb = new Bunifu.UI.WinForms.BunifuTextBox();
            this.Tyıltb = new Bunifu.UI.WinForms.BunifuTextBox();
            this.SerinoTb = new Bunifu.UI.WinForms.BunifuTextBox();
            this.Tadtb = new Bunifu.UI.WinForms.BunifuTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.Turquoise;
            this.label1.Location = new System.Drawing.Point(414, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(162, 37);
            this.label1.TabIndex = 2;
            this.label1.Text = "YEŞ TEKNE";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.Turquoise;
            this.label2.Location = new System.Drawing.Point(389, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(235, 37);
            this.label2.TabIndex = 3;
            this.label2.Text = "Yeni Tekne Ekle";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.Turquoise;
            this.label4.Location = new System.Drawing.Point(221, 154);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(157, 37);
            this.label4.TabIndex = 6;
            this.label4.Text = "Tekne Adı";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.Turquoise;
            this.label5.Location = new System.Drawing.Point(532, 278);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(209, 37);
            this.label5.TabIndex = 8;
            this.label5.Text = "Tekne Seri No";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.Turquoise;
            this.label6.Location = new System.Drawing.Point(532, 154);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(145, 37);
            this.label6.TabIndex = 10;
            this.label6.Text = "Tekne Yılı";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.Turquoise;
            this.label7.Location = new System.Drawing.Point(221, 278);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(178, 37);
            this.label7.TabIndex = 12;
            this.label7.Text = "Tekne Fiyat";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.Turquoise;
            this.label8.Location = new System.Drawing.Point(380, 392);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(264, 37);
            this.label8.TabIndex = 14;
            this.label8.Text = "Tekne Satılış Saati";
            // 
            // ZamanlamaCb
            // 
            this.ZamanlamaCb.FormattingEnabled = true;
            this.ZamanlamaCb.Items.AddRange(new object[] {
            "08:00 - 09:00",
            "09:00 - 10:00",
            "10:00 - 11:00",
            "11:00 - 12:00",
            "12:00 - 13:00",
            "13:00 - 14:00",
            "14:00 - 15:00",
            "15:00 - 16:00",
            "16:00 - 17:00"});
            this.ZamanlamaCb.Location = new System.Drawing.Point(387, 432);
            this.ZamanlamaCb.Name = "ZamanlamaCb";
            this.ZamanlamaCb.Size = new System.Drawing.Size(260, 24);
            this.ZamanlamaCb.TabIndex = 15;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.button1.Location = new System.Drawing.Point(559, 500);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(127, 51);
            this.button1.TabIndex = 16;
            this.button1.Text = "Ekle";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.PaleTurquoise;
            this.button2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.button2.Location = new System.Drawing.Point(351, 500);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(127, 51);
            this.button2.TabIndex = 17;
            this.button2.Text = "Sıfırla ";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.PaleTurquoise;
            this.button4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button4.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.button4.Location = new System.Drawing.Point(874, 558);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(127, 35);
            this.button4.TabIndex = 19;
            this.button4.Text = "Geri";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // guna2CirclePictureBox2
            // 
            this.guna2CirclePictureBox2.Image = global::Projem.Properties.Resources.ship_boat__1_;
            this.guna2CirclePictureBox2.ImageRotate = 0F;
            this.guna2CirclePictureBox2.Location = new System.Drawing.Point(957, 9);
            this.guna2CirclePictureBox2.Name = "guna2CirclePictureBox2";
            this.guna2CirclePictureBox2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox2.Size = new System.Drawing.Size(65, 62);
            this.guna2CirclePictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox2.TabIndex = 36;
            this.guna2CirclePictureBox2.TabStop = false;
            this.guna2CirclePictureBox2.Click += new System.EventHandler(this.guna2CirclePictureBox2_Click);
            // 
            // guna2CirclePictureBox1
            // 
            this.guna2CirclePictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2CirclePictureBox1.Image")));
            this.guna2CirclePictureBox1.ImageRotate = 0F;
            this.guna2CirclePictureBox1.Location = new System.Drawing.Point(12, 9);
            this.guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            this.guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox1.Size = new System.Drawing.Size(109, 109);
            this.guna2CirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox1.TabIndex = 35;
            this.guna2CirclePictureBox1.TabStop = false;
            // 
            // Tfiyattb
            // 
            this.Tfiyattb.AcceptsReturn = false;
            this.Tfiyattb.AcceptsTab = false;
            this.Tfiyattb.AnimationSpeed = 200;
            this.Tfiyattb.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Tfiyattb.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Tfiyattb.AutoSizeHeight = true;
            this.Tfiyattb.BackColor = System.Drawing.Color.Transparent;
            this.Tfiyattb.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Tfiyattb.BackgroundImage")));
            this.Tfiyattb.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.Tfiyattb.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.Tfiyattb.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.Tfiyattb.BorderColorIdle = System.Drawing.Color.Silver;
            this.Tfiyattb.BorderRadius = 1;
            this.Tfiyattb.BorderThickness = 1;
            this.Tfiyattb.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.Tfiyattb.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Tfiyattb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Tfiyattb.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.Tfiyattb.DefaultText = "";
            this.Tfiyattb.FillColor = System.Drawing.Color.White;
            this.Tfiyattb.HideSelection = true;
            this.Tfiyattb.IconLeft = null;
            this.Tfiyattb.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.Tfiyattb.IconPadding = 10;
            this.Tfiyattb.IconRight = null;
            this.Tfiyattb.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.Tfiyattb.Lines = new string[0];
            this.Tfiyattb.Location = new System.Drawing.Point(228, 318);
            this.Tfiyattb.MaxLength = 32767;
            this.Tfiyattb.MinimumSize = new System.Drawing.Size(1, 1);
            this.Tfiyattb.Modified = false;
            this.Tfiyattb.Multiline = false;
            this.Tfiyattb.Name = "Tfiyattb";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Tfiyattb.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.Tfiyattb.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Tfiyattb.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Tfiyattb.OnIdleState = stateProperties4;
            this.Tfiyattb.Padding = new System.Windows.Forms.Padding(3);
            this.Tfiyattb.PasswordChar = '\0';
            this.Tfiyattb.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.Tfiyattb.PlaceholderText = "";
            this.Tfiyattb.ReadOnly = false;
            this.Tfiyattb.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Tfiyattb.SelectedText = "";
            this.Tfiyattb.SelectionLength = 0;
            this.Tfiyattb.SelectionStart = 0;
            this.Tfiyattb.ShortcutsEnabled = true;
            this.Tfiyattb.Size = new System.Drawing.Size(250, 36);
            this.Tfiyattb.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.Tfiyattb.TabIndex = 11;
            this.Tfiyattb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Tfiyattb.TextMarginBottom = 0;
            this.Tfiyattb.TextMarginLeft = 3;
            this.Tfiyattb.TextMarginTop = 1;
            this.Tfiyattb.TextPlaceholder = "";
            this.Tfiyattb.UseSystemPasswordChar = false;
            this.Tfiyattb.WordWrap = true;
            // 
            // Tyıltb
            // 
            this.Tyıltb.AcceptsReturn = false;
            this.Tyıltb.AcceptsTab = false;
            this.Tyıltb.AnimationSpeed = 200;
            this.Tyıltb.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Tyıltb.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Tyıltb.AutoSizeHeight = true;
            this.Tyıltb.BackColor = System.Drawing.Color.Transparent;
            this.Tyıltb.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Tyıltb.BackgroundImage")));
            this.Tyıltb.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.Tyıltb.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.Tyıltb.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.Tyıltb.BorderColorIdle = System.Drawing.Color.Silver;
            this.Tyıltb.BorderRadius = 1;
            this.Tyıltb.BorderThickness = 1;
            this.Tyıltb.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.Tyıltb.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Tyıltb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Tyıltb.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.Tyıltb.DefaultText = "";
            this.Tyıltb.FillColor = System.Drawing.Color.White;
            this.Tyıltb.HideSelection = true;
            this.Tyıltb.IconLeft = null;
            this.Tyıltb.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.Tyıltb.IconPadding = 10;
            this.Tyıltb.IconRight = null;
            this.Tyıltb.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.Tyıltb.Lines = new string[0];
            this.Tyıltb.Location = new System.Drawing.Point(539, 194);
            this.Tyıltb.MaxLength = 32767;
            this.Tyıltb.MinimumSize = new System.Drawing.Size(1, 1);
            this.Tyıltb.Modified = false;
            this.Tyıltb.Multiline = false;
            this.Tyıltb.Name = "Tyıltb";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Tyıltb.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.Tyıltb.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Tyıltb.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.Empty;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Tyıltb.OnIdleState = stateProperties8;
            this.Tyıltb.Padding = new System.Windows.Forms.Padding(3);
            this.Tyıltb.PasswordChar = '\0';
            this.Tyıltb.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.Tyıltb.PlaceholderText = "";
            this.Tyıltb.ReadOnly = false;
            this.Tyıltb.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Tyıltb.SelectedText = "";
            this.Tyıltb.SelectionLength = 0;
            this.Tyıltb.SelectionStart = 0;
            this.Tyıltb.ShortcutsEnabled = true;
            this.Tyıltb.Size = new System.Drawing.Size(250, 36);
            this.Tyıltb.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.Tyıltb.TabIndex = 9;
            this.Tyıltb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Tyıltb.TextMarginBottom = 0;
            this.Tyıltb.TextMarginLeft = 3;
            this.Tyıltb.TextMarginTop = 1;
            this.Tyıltb.TextPlaceholder = "";
            this.Tyıltb.UseSystemPasswordChar = false;
            this.Tyıltb.WordWrap = true;
            // 
            // SerinoTb
            // 
            this.SerinoTb.AcceptsReturn = false;
            this.SerinoTb.AcceptsTab = false;
            this.SerinoTb.AnimationSpeed = 200;
            this.SerinoTb.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.SerinoTb.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.SerinoTb.AutoSizeHeight = true;
            this.SerinoTb.BackColor = System.Drawing.Color.Transparent;
            this.SerinoTb.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("SerinoTb.BackgroundImage")));
            this.SerinoTb.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.SerinoTb.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.SerinoTb.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.SerinoTb.BorderColorIdle = System.Drawing.Color.Silver;
            this.SerinoTb.BorderRadius = 1;
            this.SerinoTb.BorderThickness = 1;
            this.SerinoTb.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.SerinoTb.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.SerinoTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.SerinoTb.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.SerinoTb.DefaultText = "";
            this.SerinoTb.FillColor = System.Drawing.Color.White;
            this.SerinoTb.HideSelection = true;
            this.SerinoTb.IconLeft = null;
            this.SerinoTb.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.SerinoTb.IconPadding = 10;
            this.SerinoTb.IconRight = null;
            this.SerinoTb.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.SerinoTb.Lines = new string[0];
            this.SerinoTb.Location = new System.Drawing.Point(539, 318);
            this.SerinoTb.MaxLength = 32767;
            this.SerinoTb.MinimumSize = new System.Drawing.Size(1, 1);
            this.SerinoTb.Modified = false;
            this.SerinoTb.Multiline = false;
            this.SerinoTb.Name = "SerinoTb";
            stateProperties9.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.SerinoTb.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.SerinoTb.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.SerinoTb.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Silver;
            stateProperties12.FillColor = System.Drawing.Color.White;
            stateProperties12.ForeColor = System.Drawing.Color.Empty;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.SerinoTb.OnIdleState = stateProperties12;
            this.SerinoTb.Padding = new System.Windows.Forms.Padding(3);
            this.SerinoTb.PasswordChar = '\0';
            this.SerinoTb.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.SerinoTb.PlaceholderText = "";
            this.SerinoTb.ReadOnly = false;
            this.SerinoTb.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.SerinoTb.SelectedText = "";
            this.SerinoTb.SelectionLength = 0;
            this.SerinoTb.SelectionStart = 0;
            this.SerinoTb.ShortcutsEnabled = true;
            this.SerinoTb.Size = new System.Drawing.Size(250, 36);
            this.SerinoTb.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.SerinoTb.TabIndex = 7;
            this.SerinoTb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.SerinoTb.TextMarginBottom = 0;
            this.SerinoTb.TextMarginLeft = 3;
            this.SerinoTb.TextMarginTop = 1;
            this.SerinoTb.TextPlaceholder = "";
            this.SerinoTb.UseSystemPasswordChar = false;
            this.SerinoTb.WordWrap = true;
            // 
            // Tadtb
            // 
            this.Tadtb.AcceptsReturn = false;
            this.Tadtb.AcceptsTab = false;
            this.Tadtb.AnimationSpeed = 200;
            this.Tadtb.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Tadtb.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Tadtb.AutoSizeHeight = true;
            this.Tadtb.BackColor = System.Drawing.Color.Transparent;
            this.Tadtb.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Tadtb.BackgroundImage")));
            this.Tadtb.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.Tadtb.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.Tadtb.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.Tadtb.BorderColorIdle = System.Drawing.Color.Silver;
            this.Tadtb.BorderRadius = 1;
            this.Tadtb.BorderThickness = 1;
            this.Tadtb.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.Tadtb.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Tadtb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Tadtb.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.Tadtb.DefaultText = "";
            this.Tadtb.FillColor = System.Drawing.Color.White;
            this.Tadtb.HideSelection = true;
            this.Tadtb.IconLeft = null;
            this.Tadtb.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.Tadtb.IconPadding = 10;
            this.Tadtb.IconRight = null;
            this.Tadtb.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.Tadtb.Lines = new string[0];
            this.Tadtb.Location = new System.Drawing.Point(228, 194);
            this.Tadtb.MaxLength = 32767;
            this.Tadtb.MinimumSize = new System.Drawing.Size(1, 1);
            this.Tadtb.Modified = false;
            this.Tadtb.Multiline = false;
            this.Tadtb.Name = "Tadtb";
            stateProperties13.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties13.FillColor = System.Drawing.Color.Empty;
            stateProperties13.ForeColor = System.Drawing.Color.Empty;
            stateProperties13.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Tadtb.OnActiveState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties14.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.Tadtb.OnDisabledState = stateProperties14;
            stateProperties15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties15.FillColor = System.Drawing.Color.Empty;
            stateProperties15.ForeColor = System.Drawing.Color.Empty;
            stateProperties15.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Tadtb.OnHoverState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.Silver;
            stateProperties16.FillColor = System.Drawing.Color.White;
            stateProperties16.ForeColor = System.Drawing.Color.Empty;
            stateProperties16.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Tadtb.OnIdleState = stateProperties16;
            this.Tadtb.Padding = new System.Windows.Forms.Padding(3);
            this.Tadtb.PasswordChar = '\0';
            this.Tadtb.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.Tadtb.PlaceholderText = "";
            this.Tadtb.ReadOnly = false;
            this.Tadtb.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Tadtb.SelectedText = "";
            this.Tadtb.SelectionLength = 0;
            this.Tadtb.SelectionStart = 0;
            this.Tadtb.ShortcutsEnabled = true;
            this.Tadtb.Size = new System.Drawing.Size(250, 36);
            this.Tadtb.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.Tadtb.TabIndex = 5;
            this.Tadtb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Tadtb.TextMarginBottom = 0;
            this.Tadtb.TextMarginLeft = 3;
            this.Tadtb.TextMarginTop = 1;
            this.Tadtb.TextPlaceholder = "";
            this.Tadtb.UseSystemPasswordChar = false;
            this.Tadtb.WordWrap = true;
            // 
            // TekneEkle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1034, 627);
            this.Controls.Add(this.guna2CirclePictureBox2);
            this.Controls.Add(this.guna2CirclePictureBox1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.ZamanlamaCb);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Tfiyattb);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Tyıltb);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.SerinoTb);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Tadtb);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "TekneEkle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TekneEkle";
            this.Load += new System.EventHandler(this.TekneEkle_Load);
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private Bunifu.UI.WinForms.BunifuTextBox Tadtb;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private Bunifu.UI.WinForms.BunifuTextBox SerinoTb;
        private System.Windows.Forms.Label label6;
        private Bunifu.UI.WinForms.BunifuTextBox Tyıltb;
        private System.Windows.Forms.Label label7;
        private Bunifu.UI.WinForms.BunifuTextBox Tfiyattb;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox ZamanlamaCb;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox2;
    }
}